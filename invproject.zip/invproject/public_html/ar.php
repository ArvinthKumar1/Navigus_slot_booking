<html>
<head>
<title>Navigus_project</title>
<link rel="stylesheet" type="text/css" href="profilestyle.css">
</head>

<body>
<div class="backImg" />
<div class="profile" />
<img src="logo1.png">
<div class="profileText" />
<h2>Arvinth K</h2>
<h3>16MIS0076</h3>
<button type="button" onclick="window.location.href='index.php'">Visit our Page</a></button>
</body>
</html>